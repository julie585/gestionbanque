


<H1>BIENVENUE</H1>

<p> Votre compte a été crée avec succès. </p>
<p>Voici ci dessous vos parametres de connection</p>

Nom d'utilisateur : <?php echo e($username); ?> <br>
Mot de Passe :  <?php echo e($pass); ?>              <br>
Code de sécurité :  <?php echo e($code); ?>              <br>