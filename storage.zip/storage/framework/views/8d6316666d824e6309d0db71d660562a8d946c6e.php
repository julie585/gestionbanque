<form role="form" method="POST" action="<?php echo e(url('/superieur/consultcompte')); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="col-md-12">
        <div class="col-md-4">
            <label for="nom">Numéro de compte</label>
            <div class="form-group form-float">
                <div class="form-line">
                    <input type="number" class="form-control" id="solde" name="solde" placeholder="Numéro du compte" required onkeypress="return valid_number(event);">
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <label for="nom"></label>
            <div class="form-group form-float">

                <div class="button-demo">
                    <button class="btn btn-primary waves-effect" type="submit" >VALIDER
                    </button>
                </div>

            </div>
        </div>
    </div>
</form>