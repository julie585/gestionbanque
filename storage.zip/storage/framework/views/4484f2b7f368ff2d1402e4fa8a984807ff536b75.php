

<?php $__env->startSection('head'); ?>

    <style type="text/css" xmlns="http://www.w3.org/1999/html">
        .a {
            margin-left: 20px;
        }
        .titre{
            color: white;
            background-color: #1f91f3 !important;
            border-radius: 5px;
            font-size: medium;
        }
    </style>

    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Colorpicker Css -->
    <?php echo HTML::style('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css'); ?>

    <!-- Dropzone Css -->
    <?php echo HTML::style('plugins/dropzone/dropzone.css'); ?>

    <!-- Multi Select Css -->
    <?php echo HTML::style('plugins/multi-select/css/multi-select.css'); ?>


    <!-- Bootstrap Spinner Css -->
    <?php echo HTML::style('plugins/jquery-spinner/css/bootstrap-spinner.css'); ?>


    <!-- Bootstrap Tagsinput Css -->
    <?php echo HTML::style('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'); ?>


    <!-- Bootstrap Select Css -->
    <?php echo HTML::style('plugins/bootstrap-select/css/bootstrap-select.css'); ?>


    <!-- noUISlider Css -->
    <?php echo HTML::style('plugins/nouislider/nouislider.min.css'); ?>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet"
          type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">


    <!-- Colorpicker Css -->
    <?php echo HTML::style('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css'); ?>


    <!-- Dropzone Css -->
    <?php echo HTML::style('plugins/dropzone/dropzone.css'); ?>


    <!-- Multi Select Css -->
    <?php echo HTML::style('plugins/multi-select/css/multi-select.css'); ?>


    <!-- Bootstrap Spinner Css -->
    <?php echo HTML::style('plugins/jquery-spinner/css/bootstrap-spinner.css'); ?>


    <!-- Bootstrap Tagsinput Css -->
    <?php echo HTML::style('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'); ?>


    <!-- Bootstrap Select Css -->
    <?php echo HTML::style('plugins/bootstrap-select/css/bootstrap-select.css'); ?>


    <!-- noUISlider Css -->
    <?php echo HTML::style('plugins/nouislider/nouislider.min.css'); ?>

<?php $__env->stopSection(); ?>
<?php if($val == "epargne"): ?>

    <?php

    $client = \Illuminate\Support\Facades\DB::table('compteepargne')
                ->join('client','compteepargne.client_id','=','client.id')
                ->get();

    ?>



                <div>
                    <label for="clients">Nom du Client</label>
                    <select onchange="ecran($(this).val(),'idlistecompte','superieur.contenu.retraitfinepargne')" class="form-control show-tick"  name="client" >
                        <option></option>
                        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->id); ?>" ><?php echo e($client->nom); ?>  <?php echo e($client->prenom); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>












<?php endif; ?>


<?php if($val == "courant"): ?>
    <?php

    $client = \Illuminate\Support\Facades\DB::table('comptecourant')
        ->join('client','comptecourant.client_id','=','client.id')
        ->get();

    ?>



    <div>
        <label for="clients">Nom du Client</label>
        <select onchange="ecran($(this).val(),'idlistecompte','superieur.contenu.retraitfincourant')" class="form-control show-tick"  name="client" >
            <option></option>
            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($client->id); ?>" ><?php echo e($client->nom); ?>  <?php echo e($client->prenom); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>


<?php endif; ?>



<?php $__env->startSection('scripts'); ?>

    <!-- Bootstrap Colorpicker Js -->
    <?php echo HTML::script('plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js'); ?>

    <!-- Dropzone Plugin Js -->
    <?php echo HTML::script('plugins/dropzone/dropzone.js'); ?>


    <!-- Input Mask Plugin Js -->
    <?php echo HTML::script('plugins/jquery-inputmask/jquery.inputmask.bundle.js'); ?>


    <!-- Multi Select Plugin Js -->
    <?php echo HTML::script('plugins/multi-select/js/jquery.multi-select.js'); ?>


    <!-- Jquery Spinner Plugin Js -->
    <?php echo HTML::script('plugins/jquery-spinner/js/jquery.spinner.js'); ?>


    <!-- Bootstrap Tags Input Plugin Js -->
    <?php echo HTML::script('plugins/bootstrap-tagsinput/bootstrap-tagsinput.js'); ?>


    <!-- noUISlider Plugin Js -->
    <?php echo HTML::script('plugins/nouislider/nouislider.js'); ?>


    <!-- Custom Js -->
    <?php echo HTML::script('js/pages/forms/advanced-form-elements.js'); ?>


    <?php echo HTML::script('js/helpers.js'); ?>


    <?php echo HTML::script('js/pages/forms/basic-form-elements.js'); ?>


<?php $__env->stopSection(); ?>