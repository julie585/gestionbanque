<ul>

    <?php $__currentLoopData = $sup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $superieur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($superieur->nom); ?>

            <a href="<?php echo e(URL::route('superieur.edit',$superieur->id)); ?>" >Editer</a>
        </li>

        <li>
            <?php echo e($superieur->code); ?>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>