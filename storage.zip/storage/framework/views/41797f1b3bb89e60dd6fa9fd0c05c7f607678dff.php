    <?php

    $resultat = \Illuminate\Support\Facades\DB::table('client')
        ->where('prenom' ,'=',$val)
        ->first();

    ?>

    <td><strong><?php echo e($resultat->nom); ?></strong></td>
    <td><strong><?php echo e($resultat->prenom); ?></strong></td>
    <td><strong><?php echo e($resultat->age); ?></strong></td>
    <td><?php echo e($resultat->email); ?></td>
