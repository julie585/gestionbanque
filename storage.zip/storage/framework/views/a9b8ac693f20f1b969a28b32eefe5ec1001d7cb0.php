<?php echo e(Form::model(
        $sup,[
                'method'=> $sup->id? 'PUT' : 'POST',
                'route'=>
                         $sup->id?  [ 'superieur.update', $sup->id
                 ]: 'superieur.store'
        ]

 )); ?>

<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

    <?php echo e(Form::text('nom')); ?>

    <?php echo e(Form::text('prenom')); ?>


    <button type="submit">Sauvegarder</button>

<?php echo e(Form::close()); ?>