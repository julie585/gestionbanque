<?php $__currentLoopData = $compte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><strong><?php echo e($compte->id); ?></strong></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>


    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
