<?php $__env->startSection('head'); ?>

    <style type="text/css" xmlns="http://www.w3.org/1999/html">
        .a {
            margin-left: 20px;
        }
        .titre{
            color: white;
            background-color: #1f91f3 !important;
            border-radius: 5px;
            font-size: medium;
        }
    </style>

    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Colorpicker Css -->
    <?php echo HTML::style('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css'); ?>

    <!-- Dropzone Css -->
    <?php echo HTML::style('plugins/dropzone/dropzone.css'); ?>

    <!-- Multi Select Css -->
    <?php echo HTML::style('plugins/multi-select/css/multi-select.css'); ?>


    <!-- Bootstrap Spinner Css -->
    <?php echo HTML::style('plugins/jquery-spinner/css/bootstrap-spinner.css'); ?>


    <!-- Bootstrap Tagsinput Css -->
    <?php echo HTML::style('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'); ?>


    <!-- Bootstrap Select Css -->
    <?php echo HTML::style('plugins/bootstrap-select/css/bootstrap-select.css'); ?>


    <!-- noUISlider Css -->
    <?php echo HTML::style('plugins/nouislider/nouislider.min.css'); ?>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet"
          type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">


    <!-- Colorpicker Css -->
    <?php echo HTML::style('plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css'); ?>


    <!-- Dropzone Css -->
    <?php echo HTML::style('plugins/dropzone/dropzone.css'); ?>


    <!-- Multi Select Css -->
    <?php echo HTML::style('plugins/multi-select/css/multi-select.css'); ?>


    <!-- Bootstrap Spinner Css -->
    <?php echo HTML::style('plugins/jquery-spinner/css/bootstrap-spinner.css'); ?>


    <!-- Bootstrap Tagsinput Css -->
    <?php echo HTML::style('plugins/bootstrap-tagsinput/bootstrap-tagsinput.css'); ?>


    <!-- Bootstrap Select Css -->
    <?php echo HTML::style('plugins/bootstrap-select/css/bootstrap-select.css'); ?>


    <!-- noUISlider Css -->
    <?php echo HTML::style('plugins/nouislider/nouislider.min.css'); ?>


    <?php echo HTML::style('plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>

    <!--<div class="a">
        <h2>
            Nouvelle cotisation Etape 2 : Enregistrement de la cotisation
        </h2>
    </div>-->
    <div class="panel panel-heading">
        <strong>BIENVENUE Mr <?php echo e(auth()->user()->nom); ?></strong>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>



    <div class="body">

        <div class="panel-primary">
            <div class="titre">
                <strong>Liste des employés</strong>
            </div>
        </div>

        </br>
    </div>

    <div class="body">

        <H3>Employés Simple</H3>

        <div class="table-responsive">

            <table class="table table-bordered table-striped table-hover js-basic-example dataTable" >
                <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Operation Effectué</th>
                    <th>Comptes Clients crées</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Operation Effectué</th>
                    <th>Comptes Clients crées</th>
                </tr>
                </tfoot>
                <tbody>
                <?php $__currentLoopData = $employe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e($employe->nom); ?></strong></td>
                        <td><strong><?php echo e($employe->prenom); ?></strong></td>
                        <td><?php echo e($employe->email); ?></td>
                        <td><?php echo e($employe->age); ?></td>
                        <td>
                            <form method="post" action="<?php echo e(url('/superieur/getoperation',$id = [$employe->id] )); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="id" value="<?php echo $employe-> id; ?>">
                                <button class="b" ><span class='glyphicon glyphicon-eye-open'></span>
                                </button>
                            </form>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(url('/superieur/comptecreeemp',$id = [$employe->id] )); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="id" value="<?php echo $employe-> id; ?>">
                                <button class="b" ><span class='glyphicon glyphicon-eye-open'></span>
                                </button>
                            </form>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

                <br>
        <H3>Superieur Hiérarchique</H3>

        <div class="table-responsive">

            <table class="table table-bordered table-striped table-hover js-basic-example dataTable" >
                <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Operation Effectué</th>
                    <th>Comptes Clients Crée</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Operation Effectué</th>
                    <th>Comptes Clients Crée</th>
                </tr>
                </tfoot>
                <tbody>
                <?php $__currentLoopData = $superieur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $superieur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><strong><?php echo e($superieur->nom); ?></strong></td>
                    <td><strong><?php echo e($superieur->prenom); ?></strong></td>
                    <td><?php echo e($superieur->email); ?></td>
                    <td><?php echo e($superieur->age); ?></td>
                    <td>
                        <form method="post" action="<?php echo e(url('/superieur/getoperationsup',$id = [$superieur->id] )); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="id" value="<?php echo $superieur-> id; ?>">
                            <button class="b" ><span class='glyphicon glyphicon-eye-open'></span>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(url('/superieur/comptecree',$id = [$superieur->id] )); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="id" value="<?php echo $superieur-> id; ?>">
                            <button class="b" ><span class='glyphicon glyphicon-eye-open'></span>
                            </button>
                        </form>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <!-- JQuery DataTable Css -->

    <!-- Jquery DataTable Plugin Js -->
    <?php echo HTML::script('plugins/jquery-datatable/jquery.dataTables.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/buttons.flash.min.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/jszip.min.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/pdfmake.min.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/vfs_fonts.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/buttons.html5.min.js'); ?>

    <?php echo HTML::script('plugins/jquery-datatable/extensions/export/buttons.print.min.js'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('acceuilsup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>