<style type="text/css">
    .number{
        word-wrap: break-word;
    }

</style>



<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="info-box bg-<?php echo e($color); ?> hover-zoom-effect">
                        <div class="icon">
                            <i class="material-icons"><?php echo e($icone); ?></i>
                        </div>
                        <a href="<?php echo e($url); ?>">
                          <div class="content " >
                            <div class="number "> <strong><?php echo e($name); ?></strong></div>
                            <div class="number "><?php echo e($nbr); ?></div>
                          </div>
                        </a>
                    </div>

</div>